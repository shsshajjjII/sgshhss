<?php
include 'index.php';
var_dump(checkGmail('sjadsalahdhdhdumfdsfdsf123@gmail.com'));